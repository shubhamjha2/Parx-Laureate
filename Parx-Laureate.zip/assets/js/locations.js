var locations = [
    ['Apartment A3', "Area: 220 m<sup>2</sup>", "$36,000", 48.861472, 2.424674, "assets/img/property-01.jpg"],
    ['Apartment A1', "Area: 220 m<sup>2</sup>", "$28,000", 48.852498, 2.392101, "assets/img/property-02.jpg"],
    ['Apartment B1', "Area: 220 m<sup>2</sup>", "$40,000", 48.864639, 2.376652, "assets/img/property-03.jpg"],
    ['Apartment B2', "Area: 220 m<sup>2</sup>", "$28,000", 48.848657, 2.441883, "assets/img/property-04.jpg"],
    ['Luxury Apartment L2', "Area: 220 m<sup>2</sup>", "$28,000", 48.850182, 2.404633, "assets/img/property-01.jpg"],
    ['Luxury Apartment L1', "Area: 220 m<sup>2</sup>", "$36,000", 48.839619, 2.412014, "assets/img/property-02.jpg"],
    ['Family House', "Area: 220 m<sup>2</sup>", "$36,000", 48.853740, 2.466860,"assets/img/property-03.jpg"],
    ['Family House', "Area: 220 m<sup>2</sup>", "$36,000", 48.840693, 2.357254,"assets/img/property-04.jpg"],
    ['Family House', "Area: 220 m<sup>2</sup>", "$36,000", 48.861702, 2.496471,"assets/img/property-01.jpg"]
];